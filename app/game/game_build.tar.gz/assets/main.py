import pygame
import random
import asyncio

# --- 1. НАСТРОЙКИ ---
WIDTH, HEIGHT = 400, 600
FPS = 60
GRAVITY = 0.5
JUMP_FORCE = -15
FINISH_SCORE = 8000

async def main():
    pygame.init()
    screen = pygame.display.set_mode((WIDTH, HEIGHT))
    pygame.display.set_caption("Doodle Jump: Web & Mobile")
    clock = pygame.time.Clock()
    font = pygame.font.SysFont("sans-serif", 24, bold=True)

    # Классы внутри main, чтобы избежать проблем с инициализацией в вебе
    class Player:
        def __init__(self):
            self.rect = pygame.Rect(185, 450, 30, 30)
            self.dy = 0

        def move(self):
            self.dy += GRAVITY
            self.rect.y += self.dy

            keys = pygame.key.get_pressed()
            mouse_pressed = pygame.mouse.get_pressed()[0]
            mouse_x = pygame.mouse.get_pos()[0]

            # Управление для ПК и Мобилок
            if keys[pygame.K_LEFT] or (mouse_pressed and mouse_x < WIDTH // 2):
                self.rect.x -= 7
            if keys[pygame.K_RIGHT] or (mouse_pressed and mouse_x >= WIDTH // 2):
                self.rect.x += 7

            if self.rect.left > WIDTH: self.rect.right = 0
            if self.rect.right < 0: self.rect.left = WIDTH

    class Enemy:
        def __init__(self, y, season_type):
            self.rect = pygame.Rect(random.randint(0, WIDTH - 40), y, 40, 40)
            self.type = season_type
            self.speed = random.randint(2, 4)
            self.direction = 1 if random.random() > 0.5 else -1

        def update(self):
            self.rect.x += self.speed * self.direction
            if self.rect.right >= WIDTH or self.rect.left <= 0:
                self.direction *= -1

    class Coin:
        def __init__(self, x, y, img):
            self.rect = pygame.Rect(x + 7, y - 50, 45, 45)
            self.image = img

        def draw(self, screen):
            if self.image:
                screen.blit(self.image, (self.rect.x, self.rect.y))
            else:
                pygame.draw.circle(screen, (255, 215, 0), self.rect.center, 20)

    def load_img(name, size):
        try:
            img = pygame.image.load(name).convert_alpha()
            return pygame.transform.scale(img, size)
        except:
            return None

    # Загрузка ресурсов
    bg_autumn = load_img('autumn.png', (WIDTH, HEIGHT))
    bg_winter = load_img('winter.png', (WIDTH, HEIGHT))
    bg_spring = load_img('spring.png', (WIDTH, HEIGHT))
    doodle_img = load_img('doodler.png', (30, 30))
    coin_img = load_img('coin.png', (45, 45))

    enemy_imgs = {
        'autumn': load_img('enemy_autumn.png', (40, 40)),
        'winter': load_img('enemy_winter.png', (40, 40)),
        'spring': load_img('enemy_spring.png', (40, 40))
    }

    player = Player()
    start_platform = pygame.Rect(170, 530, 60, 10)
    platforms = [start_platform]
    for i in range(1, 7):
        platforms.append(pygame.Rect(random.randint(0, WIDTH - 60), i * 80, 60, 10))

    enemies, coins = [], []
    score, coin_count = 0, 0
    game_won, running = False, True

    while running:
        # Логика сезонов
        if score < 2500:
            current_season, current_bg, txt_color = 'autumn', bg_autumn, (255, 255, 255)
        elif score < 5500:
            current_season, current_bg, txt_color = 'winter', bg_winter, (0, 0, 100)
        else:
            current_season, current_bg, txt_color = 'spring', bg_spring, (0, 80, 0)

        if current_bg: screen.blit(current_bg, (0, 0))
        else: screen.fill((200, 200, 200))

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False

        if not game_won:
            player.move()

            for p in platforms:
                if player.rect.colliderect(p) and player.dy > 0:
                    if player.rect.bottom <= p.bottom + 10:
                        player.dy = JUMP_FORCE

            for c in coins[:]:
                if player.rect.colliderect(c.rect):
                    coin_count += 1
                    coins.remove(c)

            for en in enemies:
                en.update()
                if player.rect.colliderect(en.rect):
                    player.__init__(); score = 0; enemies = []; coins = []

            if player.rect.y < 200:
                diff = 200 - player.rect.y
                player.rect.y = 200
                score += diff
                for p in platforms:
                    p.y += diff
                    if p.y > HEIGHT:
                        if score < FINISH_SCORE:
                            p.y = 0; p.x = random.randint(0, WIDTH - 60)
                            if random.random() < 0.10: enemies.append(Enemy(p.y - 40, current_season))
                            elif random.random() < 0.20: coins.append(Coin(p.x, p.y, coin_img))
                        else: p.y = -100

                for en in enemies: en.rect.y += diff
                for c in coins: c.rect.y += diff
                enemies = [en for en in enemies if en.rect.y < HEIGHT + 100]
                coins = [c for c in coins if c.rect.y < HEIGHT + 100]

            if score >= FINISH_SCORE and len([p for p in platforms if p.y > 0]) == 0:
                game_won = True
            if player.rect.y > HEIGHT:
                player.__init__(); score = 0; enemies = []; coins = []

        # Отрисовка
        for p in platforms: pygame.draw.rect(screen, (120, 120, 120), p)
        for c in coins: c.draw(screen)
        for en in enemies:
            img = enemy_imgs[en.type]
            if img: screen.blit(img, (en.rect.x, en.rect.y))
            else: pygame.draw.circle(screen, (200, 0, 0), en.rect.center, 20)

        if doodle_img: screen.blit(doodle_img, (player.rect.x, player.rect.y))
        else: pygame.draw.rect(screen, (0, 200, 0), player.rect)

        screen.blit(font.render(f"Height: {int(score)}", True, txt_color), (15, 15))
        screen.blit(font.render(f"Coins: {coin_count}", True, (255, 215, 0)), (15, 45))
        if game_won:
            win_txt = font.render("WIN! ALL SEASONS DONE!", True, (255, 0, 0))
            screen.blit(win_txt, (WIDTH // 2 - 140, HEIGHT // 2))

        pygame.display.flip()
        clock.tick(FPS)
        await asyncio.sleep(0)  # Важно для работы браузера

asyncio.run(main())